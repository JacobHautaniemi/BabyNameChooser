const socket = io();

const joinBtn = document.getElementById('join-btn');
const joinSection = document.getElementById('join-section');
const game = document.getElementById('game');
const nameDisplay = document.getElementById('name-display');
const heart = document.getElementById('heart');
const thumbsUpBtn = document.getElementById('thumbs-up');
const thumbsDownBtn = document.getElementById('thumbs-down');

joinBtn.addEventListener('click', () => {
    socket.emit('join');
    joinSection.style.display = 'none';
    game.style.display = 'block';
});

function resetVoteButtons() {
    thumbsUpBtn.disabled = false;
    thumbsDownBtn.disabled = false;
    thumbsUpBtn.classList.remove('selected');
    thumbsDownBtn.classList.remove('selected');
}

function vote(voteType) {
    socket.emit('vote', voteType);
    if (voteType === 'up') {
        thumbsUpBtn.classList.add('selected');
        thumbsDownBtn.disabled = true;
    } else {
        thumbsDownBtn.classList.add('selected');
        thumbsUpBtn.disabled = true;
    }
}

thumbsUpBtn.addEventListener('click', () => vote('up'));
thumbsDownBtn.addEventListener('click', () => vote('down'));

socket.on('updateName', (nameData) => {
    nameDisplay.textContent = nameData.name;
    nameDisplay.className = nameData.gender === 'male' ? 'blue' : 'pink';
    resetVoteButtons();
    heart.classList.remove('show');
    DownThumb.classList.remove('show');
});

socket.on('match', (name) => {
    nameDisplay.textContent = `You've matched on ${name}!`;
    nameDisplay.className = '';
    thumbsUpBtn.disabled = true;
    thumbsDownBtn.disabled = true;
    heart.classList.remove('show');
    DownThumb.classList.remove('show');
});

socket.on('resetVote', () => {
    resetVoteButtons();
    heart.classList.remove('show');
    DownThumb.classList.remove('show');
});

socket.on('showHeart', () => {
    heart.classList.add('show');
});

socket.on('showDownThumb', () => {
    DownThumb.classList.add('show');
})